# 🥗 NutriTrack — Nutrition & Calorie Tracker

A full-stack nutrition tracking web app with user login, calorie logging, macro tracking, calorie history, and AI-powered food search. Built with React + Vite + Supabase.

---

## Features

- 📧 Email/password authentication (login & signup)
- 🍽 Log foods to breakfast, lunch, and dinner
- 🔍 Search 60+ built-in foods + AI-powered unlimited food search
- 📊 Macro rings showing protein, carbs, fat progress
- 📈 Calorie history chart (14 days)
- 🎯 Customizable daily calorie goal (saved per user)
- 📱 Mobile-friendly, installable as a PWA
- 🔒 Data isolated per user (Row Level Security)

---

## Setup (takes ~15 minutes)

### Step 1 — Supabase (database + auth)

1. Go to [supabase.com](https://supabase.com) → New project (free)
2. Go to **SQL Editor → New Query**, paste and run the SQL below:

```sql
create table profiles (
  id uuid references auth.users on delete cascade primary key,
  email text,
  calorie_goal integer default 2000,
  created_at timestamptz default now()
);

create table meal_logs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users on delete cascade not null,
  date date not null default current_date,
  meal text not null check (meal in ('breakfast','lunch','dinner')),
  food_name text not null,
  calories integer not null,
  protein integer not null default 0,
  carbs integer not null default 0,
  fat integer not null default 0,
  created_at timestamptz default now()
);

create table daily_history (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users on delete cascade not null,
  date date not null,
  total_calories integer not null default 0,
  unique(user_id, date)
);

alter table profiles enable row level security;
alter table meal_logs enable row level security;
alter table daily_history enable row level security;

create policy "Users manage own profile" on profiles for all using (auth.uid() = id);
create policy "Users manage own logs" on meal_logs for all using (auth.uid() = user_id);
create policy "Users manage own history" on daily_history for all using (auth.uid() = user_id);

create or replace function handle_new_user()
returns trigger as $$
begin
  insert into profiles (id, email) values (new.id, new.email);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure handle_new_user();
```

3. Go to **Settings → API** and copy:
   - **Project URL** (looks like `https://abc123.supabase.co`)
   - **anon/public key** (long string starting with `eyJ...`)

### Step 2 — Configure environment

1. Copy `.env.example` to `.env.local`:
   ```bash
   cp .env.example .env.local
   ```
2. Fill in your values:
   ```
   VITE_SUPABASE_URL=https://your-project-id.supabase.co
   VITE_SUPABASE_ANON_KEY=your-anon-key-here
   ```

### Step 3 — Run locally

```bash
npm install
npm run dev
```
Visit [http://localhost:5173](http://localhost:5173)

---

## Deploy to Vercel (free, shareable link)

1. Push this project to a GitHub repo
2. Go to [vercel.com](https://vercel.com) → Import Project → select your repo
3. Add environment variables in Vercel:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. Click **Deploy**

You'll get a URL like `https://nutritrack-yourname.vercel.app` — share this with anyone!

### Custom domain (optional, ~$10-15/year)

In Vercel → Settings → Domains → add your domain.

---

## Sharing with users

1. Send the Vercel URL via text or email
2. Users tap the link, create an account, and start tracking
3. On mobile: tap "Share → Add to Home Screen" to install as an app
4. Each user's data is private and persists across sessions

---

## Project Structure

```
nutrition-app/
├── src/
│   ├── components/
│   │   ├── HistoryChart.jsx   — 14-day calorie bar chart
│   │   └── MacroRing.jsx      — Protein/carbs/fat ring display
│   ├── lib/
│   │   ├── supabase.js        — Supabase client
│   │   └── foods.js           — 60+ built-in foods database
│   ├── pages/
│   │   ├── AuthPage.jsx       — Login / signup
│   │   └── TrackerPage.jsx    — Main app
│   ├── App.jsx                — Root + auth routing
│   ├── index.css              — Global styles
│   └── main.jsx               — Entry point
├── public/
│   └── manifest.json          — PWA manifest
├── .env.example               — Environment template
├── index.html
├── package.json
└── vite.config.js
```

---

## Supabase Email Auth Settings

By default, Supabase requires email confirmation. To disable this for easier testing:

**Supabase Dashboard → Authentication → Settings → Enable email confirmations → OFF**

---

## Tech Stack

- **React 18** — UI
- **Vite** — Build tool
- **Supabase** — Auth + PostgreSQL database
- **Claude AI API** — Unlimited food search (uses claude-sonnet-4-20250514)
- **Vercel** — Hosting (recommended)
