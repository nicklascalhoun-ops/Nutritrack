import { useState, useEffect, useCallback } from 'react'
import { supabase } from '../lib/supabase'
import { FOODS } from '../lib/foods'
import HistoryChart from '../components/HistoryChart'
import MacroRing from '../components/MacroRing'

const today = () => new Date().toISOString().split('T')[0]

export default function TrackerPage({ session }) {
  const [profile, setProfile] = useState({ calorie_goal: 2000 })
  const [logs, setLogs] = useState({ breakfast: [], lunch: [], dinner: [] })
  const [history, setHistory] = useState([])
  const [searchQ, setSearchQ] = useState('')
  const [searchResults, setSearchResults] = useState([])
  const [selectedMeal, setSelectedMeal] = useState('breakfast')
  const [aiStatus, setAiStatus] = useState('')
  const [aiTimer, setAiTimer] = useState(null)
  const [goalEdit, setGoalEdit] = useState(false)
  const [goalInput, setGoalInput] = useState(2000)
  const [view, setView] = useState('today')

  const totals = useCallback(() => {
    const all = [...logs.breakfast, ...logs.lunch, ...logs.dinner]
    return {
      cal: all.reduce((s, f) => s + f.calories, 0),
      protein: all.reduce((s, f) => s + f.protein, 0),
      carbs: all.reduce((s, f) => s + f.carbs, 0),
      fat: all.reduce((s, f) => s + f.fat, 0),
    }
  }, [logs])

  useEffect(() => { loadProfile(); loadTodayLogs(); loadHistory() }, [])

  async function loadProfile() {
    const { data } = await supabase.from('profiles').select('*').eq('id', session.user.id).single()
    if (data) { setProfile(data); setGoalInput(data.calorie_goal) }
  }

  async function loadTodayLogs() {
    const { data } = await supabase.from('meal_logs')
      .select('*').eq('user_id', session.user.id).eq('date', today()).order('created_at')
    if (data) {
      const grouped = { breakfast: [], lunch: [], dinner: [] }
      data.forEach(r => { if (grouped[r.meal]) grouped[r.meal].push(r) })
      setLogs(grouped)
    }
  }

  async function loadHistory() {
    const { data } = await supabase.from('daily_history')
      .select('*').eq('user_id', session.user.id).order('date', { ascending: true }).limit(14)
    if (data) setHistory(data)
  }

  async function addFood(food) {
    const entry = {
      user_id: session.user.id,
      date: today(),
      meal: selectedMeal,
      food_name: food.name,
      calories: Math.round(food.cal || food.calories),
      protein: Math.round(food.protein),
      carbs: Math.round(food.carbs),
      fat: Math.round(food.fat),
    }
    const { data } = await supabase.from('meal_logs').insert(entry).select().single()
    if (data) {
      setLogs(prev => ({ ...prev, [selectedMeal]: [...prev[selectedMeal], data] }))
      setSearchQ('')
      setSearchResults([])
      setAiStatus('')
    }
  }

  async function removeFood(id, meal) {
    await supabase.from('meal_logs').delete().eq('id', id)
    setLogs(prev => ({ ...prev, [meal]: prev[meal].filter(f => f.id !== id) }))
  }

  async function saveGoal() {
    await supabase.from('profiles').update({ calorie_goal: goalInput }).eq('id', session.user.id)
    setProfile(p => ({ ...p, calorie_goal: goalInput }))
    setGoalEdit(false)
  }

  async function logTodayToHistory() {
    const t = totals()
    await supabase.from('daily_history').upsert({
      user_id: session.user.id,
      date: today(),
      total_calories: t.cal,
    }, { onConflict: 'user_id,date' })
    loadHistory()
    alert(`Logged ${t.cal} kcal for today!`)
  }

  async function signOut() {
    await supabase.auth.signOut()
  }

  function onSearch(q) {
    setSearchQ(q)
    if (!q) { setSearchResults([]); setAiStatus(''); return }
    const local = FOODS.filter(f => f.name.toLowerCase().includes(q.toLowerCase())).slice(0, 6)
    setSearchResults(local)
    clearTimeout(aiTimer)
    const t = setTimeout(() => aiSearch(q), 700)
    setAiTimer(t)
  }

  async function aiSearch(q) {
    setAiStatus('searching')
    try {
      const resp = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          messages: [{ role: 'user', content: `Return 6 foods matching "${q}". JSON array only, no markdown. Each: {"name":"...","cal":N,"protein":N,"carbs":N,"fat":N}. Include portion sizes. Use USDA values.` }],
        })
      })
      const data = await resp.json()
      const text = data.content.map(c => c.text || '').join('')
      const parsed = JSON.parse(text.replace(/```json|```/g, '').trim())
      setSearchResults(parsed.map(f => ({ ...f, calories: f.cal })))
      setAiStatus('ok')
    } catch {
      setAiStatus('err')
    }
  }

  const t = totals()
  const goal = profile.calorie_goal
  const pct = Math.min(Math.round((t.cal / goal) * 100), 100)
  const barColor = t.cal > goal ? '#f87171' : t.cal >= goal * 0.85 ? '#fbbf24' : '#4ade80'

  return (
    <div style={s.page}>
      {/* Header */}
      <header style={s.header}>
        <div style={s.headerLeft}>
          <span style={{ fontSize: 20 }}>🥗</span>
          <span style={s.appName}>NutriTrack</span>
        </div>
        <div style={s.headerRight}>
          <span style={s.userEmail}>{session.user.email}</span>
          <button className="btn-ghost" style={{ padding: '6px 12px', fontSize: 13 }} onClick={signOut}>Sign out</button>
        </div>
      </header>

      {/* Nav */}
      <nav style={s.nav}>
        {['today', 'history'].map(v => (
          <button key={v} style={view === v ? s.navActive : s.navBtn} onClick={() => setView(v)}>
            {v === 'today' ? '📋 Today' : '📈 History'}
          </button>
        ))}
      </nav>

      <main style={s.main}>
        {view === 'today' && (
          <>
            {/* Goal Bar */}
            <div className="card" style={{ marginBottom: '1rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                <div>
                  <span style={s.sectionTitle}>Daily progress</span>
                  <span style={{ fontSize: 13, color: '#64748b', marginLeft: 10 }}>
                    {t.cal} / {goal} kcal
                  </span>
                </div>
                {goalEdit ? (
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                    <input type="number" value={goalInput} onChange={e => setGoalInput(+e.target.value)} style={{ width: 90, padding: '6px 10px' }} min={500} max={6000} step={50} />
                    <button className="btn-primary" style={{ padding: '6px 12px' }} onClick={saveGoal}>Save</button>
                    <button className="btn-ghost" style={{ padding: '6px 10px' }} onClick={() => setGoalEdit(false)}>✕</button>
                  </div>
                ) : (
                  <button className="btn-ghost" style={{ padding: '5px 10px', fontSize: 12 }} onClick={() => setGoalEdit(true)}>Edit goal</button>
                )}
              </div>
              <div style={{ height: 10, background: '#0f172a', borderRadius: 99, overflow: 'hidden' }}>
                <div style={{ height: '100%', width: pct + '%', background: barColor, borderRadius: 99, transition: 'width 0.4s, background 0.3s' }} />
              </div>
              <div style={{ display: 'flex', gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
                <span className="tag tag-green">{t.cal} kcal</span>
                <span className="tag tag-blue">{t.protein}g protein</span>
                <span className="tag tag-amber">{t.carbs}g carbs</span>
                <span className="tag" style={{ background: 'rgba(148,163,184,0.1)', color: '#94a3b8' }}>{t.fat}g fat</span>
              </div>
            </div>

            {/* Macro Rings */}
            <MacroRing totals={t} goal={goal} />

            {/* Search */}
            <div className="card" style={{ marginBottom: '1rem' }}>
              <div style={s.sectionTitle}>Add food</div>
              <div style={{ display: 'flex', gap: 8, margin: '10px 0 6px', flexWrap: 'wrap' }}>
                <input type="text" value={searchQ} onChange={e => onSearch(e.target.value)} placeholder="Search foods or describe a meal…" style={{ flex: 1, minWidth: 180 }} />
                <select value={selectedMeal} onChange={e => setSelectedMeal(e.target.value)} style={{ width: 130 }}>
                  <option value="breakfast">Breakfast</option>
                  <option value="lunch">Lunch</option>
                  <option value="dinner">Dinner</option>
                </select>
              </div>
              {aiStatus === 'searching' && <div style={s.aiNote}>🔍 Searching AI food database…</div>}
              {aiStatus === 'ok' && <div style={{ ...s.aiNote, color: '#4ade80' }}>✓ AI results</div>}
              {aiStatus === 'err' && <div style={{ ...s.aiNote, color: '#f87171' }}>⚠ AI unavailable — showing local results</div>}
              {searchResults.length > 0 && (
                <div style={s.resultsBox}>
                  {searchResults.map((f, i) => (
                    <div key={i} style={s.resultRow}>
                      <div>
                        <div style={{ fontSize: 14, fontWeight: 500, color: '#f1f5f9' }}>{f.name}</div>
                        <div style={{ fontSize: 12, color: '#64748b' }}>P: {Math.round(f.protein)}g · C: {Math.round(f.carbs)}g · F: {Math.round(f.fat)}g</div>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span className="tag tag-green">{Math.round(f.cal || f.calories)} kcal</span>
                        <button className="btn-primary" style={{ padding: '5px 12px', fontSize: 13 }} onClick={() => addFood(f)}>+ Add</button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Meal Cards */}
            <div style={s.mealsGrid}>
              {[
                { key: 'breakfast', label: 'Breakfast', icon: '☕' },
                { key: 'lunch', label: 'Lunch', icon: '🥙' },
                { key: 'dinner', label: 'Dinner', icon: '🍽' },
              ].map(({ key, label, icon }) => {
                const mealCals = logs[key].reduce((s, f) => s + f.calories, 0)
                return (
                  <div key={key} className="card">
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                      <span>{icon}</span>
                      <span style={{ fontSize: 14, fontWeight: 500 }}>{label}</span>
                      <span className="tag tag-green" style={{ marginLeft: 'auto' }}>{mealCals} kcal</span>
                    </div>
                    {logs[key].length === 0 ? (
                      <p style={{ fontSize: 13, color: '#475569', textAlign: 'center', padding: '10px 0' }}>No foods logged</p>
                    ) : (
                      logs[key].map(f => (
                        <div key={f.id} style={s.mealItem}>
                          <span style={{ fontSize: 13, flex: 1 }}>{f.food_name}</span>
                          <span style={{ fontSize: 12, color: '#64748b', marginRight: 8 }}>{f.calories} kcal</span>
                          <button onClick={() => removeFood(f.id, key)} style={{ background: 'none', border: 'none', color: '#475569', fontSize: 16, padding: 0, lineHeight: 1 }}>✕</button>
                        </div>
                      ))
                    )}
                  </div>
                )
              })}
            </div>

            <button className="btn-ghost" style={{ width: '100%', padding: '12px', fontSize: 14 }} onClick={logTodayToHistory}>
              📊 Save today to history
            </button>
          </>
        )}

        {view === 'history' && (
          <div className="card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <span style={s.sectionTitle}>Calorie history</span>
              <button className="btn-ghost" style={{ padding: '6px 12px', fontSize: 13 }} onClick={logTodayToHistory}>Log today</button>
            </div>
            <HistoryChart history={history} goal={goal} />
            {history.length === 0 && (
              <p style={{ textAlign: 'center', color: '#475569', fontSize: 14, padding: '2rem 0' }}>
                No history yet. Log meals and save your daily total to see your progress here.
              </p>
            )}
          </div>
        )}
      </main>
    </div>
  )
}

const s = {
  page: { maxWidth: 760, margin: '0 auto', padding: '0 1rem 2rem' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '1rem 0', borderBottom: '1px solid rgba(255,255,255,0.06)', marginBottom: '1rem' },
  headerLeft: { display: 'flex', alignItems: 'center', gap: 10 },
  appName: { fontSize: 18, fontWeight: 500 },
  headerRight: { display: 'flex', alignItems: 'center', gap: 10 },
  userEmail: { fontSize: 13, color: '#64748b', display: 'none' },
  nav: { display: 'flex', gap: 6, marginBottom: '1rem' },
  navBtn: { background: 'transparent', border: '1px solid rgba(255,255,255,0.08)', color: '#64748b', padding: '8px 16px', borderRadius: 8, fontSize: 14, cursor: 'pointer' },
  navActive: { background: '#1e293b', border: '1px solid rgba(255,255,255,0.15)', color: '#f1f5f9', padding: '8px 16px', borderRadius: 8, fontSize: 14, fontWeight: 500, cursor: 'pointer' },
  main: {},
  sectionTitle: { fontSize: 14, fontWeight: 500, color: '#f1f5f9' },
  resultsBox: { border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, overflow: 'hidden', marginTop: 8 },
  resultRow: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 14px', borderBottom: '1px solid rgba(255,255,255,0.05)' },
  mealsGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 12, margin: '1rem 0' },
  mealItem: { display: 'flex', alignItems: 'center', padding: '5px 0', borderBottom: '1px solid rgba(255,255,255,0.05)' },
  aiNote: { fontSize: 12, color: '#64748b', marginBottom: 4 },
}
