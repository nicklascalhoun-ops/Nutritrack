import { useState } from 'react'
import { supabase } from '../lib/supabase'

export default function AuthPage() {
  const [mode, setMode] = useState('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  async function handleSubmit(e) {
    e.preventDefault()
    setLoading(true)
    setError('')
    setSuccess('')

    if (mode === 'login') {
      const { error } = await supabase.auth.signInWithPassword({ email, password })
      if (error) setError(error.message)
    } else {
      const { error } = await supabase.auth.signUp({ email, password })
      if (error) setError(error.message)
      else setSuccess('Account created! Check your email to confirm, then log in.')
    }
    setLoading(false)
  }

  return (
    <div style={styles.page}>
      <div style={styles.box}>
        <div style={styles.logo}>
          <span style={styles.logoIcon}>🥗</span>
          <h1 style={styles.logoText}>NutriTrack</h1>
        </div>
        <p style={styles.tagline}>Your personal nutrition companion</p>

        <div style={styles.tabs}>
          <button style={mode==='login'?styles.tabActive:styles.tab} onClick={()=>{setMode('login');setError('');setSuccess('')}}>Sign in</button>
          <button style={mode==='signup'?styles.tabActive:styles.tab} onClick={()=>{setMode('signup');setError('');setSuccess('')}}>Create account</button>
        </div>

        <form onSubmit={handleSubmit} style={styles.form}>
          <div>
            <label style={styles.label}>Email</label>
            <input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" required />
          </div>
          <div>
            <label style={styles.label}>Password</label>
            <input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder={mode==='signup'?'Min 6 characters':'••••••••'} required minLength={6} />
          </div>

          {error && <div style={styles.error}>{error}</div>}
          {success && <div style={styles.successMsg}>{success}</div>}

          <button type="submit" className="btn-primary" style={{ width:'100%', padding:'12px', fontSize:'15px' }} disabled={loading}>
            {loading ? 'Please wait…' : mode==='login' ? 'Sign in' : 'Create account'}
          </button>
        </form>

        <p style={styles.footer}>
          Track calories, macros, and your progress — free forever.
        </p>
      </div>
    </div>
  )
}

const styles = {
  page: { minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', padding:'1rem' },
  box: { width:'100%', maxWidth:400, background:'#1e293b', border:'1px solid rgba(255,255,255,0.08)', borderRadius:16, padding:'2rem' },
  logo: { display:'flex', alignItems:'center', gap:10, marginBottom:6 },
  logoIcon: { fontSize:28 },
  logoText: { fontSize:24, fontWeight:500, color:'#f1f5f9' },
  tagline: { fontSize:14, color:'#64748b', marginBottom:'1.5rem' },
  tabs: { display:'flex', gap:4, background:'#0f172a', borderRadius:8, padding:4, marginBottom:'1.25rem' },
  tab: { flex:1, background:'transparent', border:'none', color:'#64748b', padding:'8px', borderRadius:6, fontSize:14, cursor:'pointer' },
  tabActive: { flex:1, background:'#334155', border:'none', color:'#f1f5f9', padding:'8px', borderRadius:6, fontSize:14, cursor:'pointer', fontWeight:500 },
  form: { display:'flex', flexDirection:'column', gap:'1rem' },
  label: { display:'block', fontSize:13, color:'#94a3b8', marginBottom:6 },
  error: { background:'rgba(248,113,113,0.1)', border:'1px solid rgba(248,113,113,0.3)', color:'#f87171', borderRadius:8, padding:'10px 14px', fontSize:13 },
  successMsg: { background:'rgba(74,222,128,0.1)', border:'1px solid rgba(74,222,128,0.3)', color:'#4ade80', borderRadius:8, padding:'10px 14px', fontSize:13 },
  footer: { marginTop:'1.25rem', fontSize:12, color:'#475569', textAlign:'center' },
}
